*{
  font-family: 'Oswald', sans-serif;
}

div.accuse{
  background-color: #f2f2f2;
  border-radius: 20px;
  padding: 20px 20px;
  margin-bottom: 20px;
}

div.grade{
  display: inline;
  margin-left: 3px;
  margin-right: 3px;
}

.radius{
  border-radius: 10px;
}

#button{
  background-color:rgba(0, 0, 0, 0.3);
}

#button:hover{
  background-color:rgba(0, 0, 48, 0.62);
}

td{
  border: 1px solid rgba(205, 205, 205, 0.1);
  border-radius: 20px;
}

#top{
  margin-bottom: 30px;
  text-align: center;
  border-bottom: solid 2px black;
}